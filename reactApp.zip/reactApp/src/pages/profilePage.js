const ProfilePage = () => {
    return <h2>My Profile </h2>
}

export default ProfilePage;